/* This file DEFINES the function that can multiply two integers */

int esw_multiply (int a, int b)
{
  return (a * b);
}


