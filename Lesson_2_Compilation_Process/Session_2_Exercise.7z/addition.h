/* This file DECLARES the function that can add two integers */

int esw_add (int a, int b);

