/* This file DEFINES the function that can add two integers */

int esw_add (int a, int b)
{
  return (a + b);
}


