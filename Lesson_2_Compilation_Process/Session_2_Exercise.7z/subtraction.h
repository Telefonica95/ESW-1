/* This file DECLARES the function that can subtract two integers */

int esw_subtract (int a, int b);

