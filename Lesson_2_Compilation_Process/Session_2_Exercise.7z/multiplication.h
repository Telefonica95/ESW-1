/* This file DECLARES the function that can multiply two integers */


